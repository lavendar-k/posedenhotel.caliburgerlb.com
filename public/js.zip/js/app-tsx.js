/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/js/app-tsx.tsx":
/*!**********************************!*\
  !*** ./resources/js/app-tsx.tsx ***!
  \**********************************/
/***/ (() => {

eval(" // import React from \"react\";\n// import { render } from \"react-dom\";\n// import PointOfSale from \"./components/PointOfSale\";\n// render(<PointOfSale />, document.getElementById(\"pos\"));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvanMvYXBwLXRzeC50c3guanMiLCJtYXBwaW5ncyI6IkNBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvanMvYXBwLXRzeC50c3g/NTlkNSJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcclxuLy8gaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG4vLyBpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwicmVhY3QtZG9tXCI7XHJcbi8vIGltcG9ydCBQb2ludE9mU2FsZSBmcm9tIFwiLi9jb21wb25lbnRzL1BvaW50T2ZTYWxlXCI7XHJcbi8vIHJlbmRlcig8UG9pbnRPZlNhbGUgLz4sIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicG9zXCIpKTtcclxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./resources/js/app-tsx.tsx\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/js/app-tsx.tsx"]();
/******/ 	
/******/ })()
;